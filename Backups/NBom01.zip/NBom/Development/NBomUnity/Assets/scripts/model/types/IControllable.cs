
using System;
using UnityEngine;

public class IControllable: MonoBehaviour
{
	public IControllable ()
	{
		
	}
	

}


