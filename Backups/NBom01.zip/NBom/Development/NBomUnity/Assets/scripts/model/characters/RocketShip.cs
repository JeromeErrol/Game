﻿using UnityEngine;
using System.Collections;
using GameUtil2D;

public class RocketShip : MonoBehaviour
{
		public int points;
		public Teleport teleport;
		
		public void Die ()
		{
				Destroy (gameObject);
				print ("Game Over");
				Application.LoadLevel ("demo");
		}

		void Update ()
		{
				FuelTank fuelTank = GetComponent<FuelTank> ();
				if (fuelTank != null) {
						if (fuelTank.FuelIsRemaining == false) {
								Die ();
						}
				}
		}

		public void SaveTeleport ()
		{
				teleport.SavePosition (gameObject.rigidbody2D.transform.position);
		}

		public void UseTeleport ()
		{
				if (teleport.Activated) {
						gameObject.rigidbody2D.transform.position = teleport.transform.position;
				}
			
		}

		void OnTriggerEnter2D (Collider2D collider2D)
		{		
				ICollideable collideable = collider2D.gameObject.GetComponent<ICollideable> ();
				if (collideable) {
						collideable.CollidedWith (this);
				}
		}

		void OnTriggerExit2D (Collider2D col)
		{			
				
		}

		void OnTriggerStay2D (Collider2D col)
		{
				IOverlap overlap = col.gameObject.GetComponent<IOverlap> ();
				if (overlap) {
						overlap.OverlappingWith (this);
				}
		}
}

