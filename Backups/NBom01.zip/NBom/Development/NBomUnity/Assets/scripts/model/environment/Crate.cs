using System;

public class Crate:ICollideable
{
		public Crate ()
		{
		}

		public override void CollidedWith (RocketShip rocketShip)
		{
			Shield shield = rocketShip.GetComponent<Shield> ();

			if (shield.Active) {
					Break();
				} else {
						rocketShip.Die();			
				}
		}

		public void Break(){
			Destroy (gameObject);
		}
}


