using System;
using UnityEngine;

public class Teleport: MonoBehaviour
{ 
		public int level;

		void Start ()
		{
				Activated = false;
		}

		public bool Activated {
				get {
						return renderer.enabled;
				}set {
						renderer.enabled = value;
				}
		}

		public void SavePosition (Vector3 position)
		{
				transform.position = position;
				Activated = true;
		}
}

