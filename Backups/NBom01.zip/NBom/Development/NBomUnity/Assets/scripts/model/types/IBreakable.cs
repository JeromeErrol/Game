using System;

public class IBreakable:ICollideable
{
		public IBreakable ()
		{
		}

		public override void CollidedWith (RocketShip rocketShip)
		{
			
		}
}

