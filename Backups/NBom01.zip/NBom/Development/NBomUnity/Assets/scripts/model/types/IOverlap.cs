using UnityEngine;
using System.Collections;
using System;

public class IOverlap : MonoBehaviour
{	
	public virtual void OverlappingWith(RocketShip rocketShip){
		throw new NotImplementedException ();
	}
}

