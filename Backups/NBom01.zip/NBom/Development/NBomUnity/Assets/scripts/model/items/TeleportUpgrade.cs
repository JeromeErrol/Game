using UnityEngine;
using System.Collections;

public class TeleportUpgrade : ICollectable
{
		public override void CollectedBy (RocketShip rocketShip)
		{
				if (rocketShip.teleport == null) {
						Teleport teleport = new Teleport ();
						Instantiate (teleport);
				} else {
						rocketShip.teleport.level++;
				}
		}
}

