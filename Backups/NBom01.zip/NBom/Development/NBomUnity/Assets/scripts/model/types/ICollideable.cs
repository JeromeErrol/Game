
using System;
using UnityEngine;

public class ICollideable: MonoBehaviour
{
		public ICollideable ()
		{
			
		}

		void Start(){

		}

		public virtual void CollidedWith(RocketShip rocketShip){
			throw new NotImplementedException ();
		}
}


