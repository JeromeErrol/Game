public enum Ability{
	Boost, Thrust
}