using UnityEngine;
using System;

namespace GameUtil2D
{
		public static class MouseUtil2D
		{
				public static void FaceMouse (GameObject gameObject)
				{
						Vector3 screenPos = Camera.main.WorldToScreenPoint (gameObject.transform.position);
						gameObject.transform.rotation = Quaternion.Euler (0, 0, Mathf.Atan2 (Input.mousePosition.y - screenPos.y, Input.mousePosition.x - screenPos.x) * Mathf.Rad2Deg - 90);
				}
		}

		public static class PhysicsUtil2D
		{
				public static void ApplyForwardForce(Rigidbody2D rigidBody2D, float amount){
					ApplyDirectedForce (rigidBody2D, rigidBody2D.transform.rotation, amount);
				}

				public static void ApplyDirectedForce(Rigidbody2D rigidBody2D, Quaternion rotation, float amount){
					rigidBody2D.AddForce (rotation * Vector3.up * amount);
				}
		}

		public static class CameraUtil2D{
			public static void SetZ (float z)
			{
				Vector3 cameraPosition = Camera.main.transform.position;
				cameraPosition.Set (cameraPosition.x, cameraPosition.y, z);
				Camera.main.transform.position = cameraPosition;
			}
		}
}

